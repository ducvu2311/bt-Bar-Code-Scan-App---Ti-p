import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, ScrollView } from 'react-native';

const PaymentScreen = ({ navigation }) => {
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');

  const onPay = () => {
    // Thực hiện xử lý thanh toán, sau đó chuyển sang Success
    navigation.replace('Success');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Payment Details</Text>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Card Number</Text>
        <TextInput 
          placeholder="5261 4141 0151 8472" 
          style={styles.input} 
          value={cardNumber} 
          onChangeText={setCardNumber} 
          keyboardType="numeric" 
        />
      </View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Cardholder Name</Text>
        <TextInput 
          placeholder="Duc Vu" 
          style={styles.input} 
          value={cardName} 
          onChangeText={setCardName} 
        />
      </View>
      <View style={styles.rowInput}>
        <View style={styles.inputHalf}>
          <Text style={styles.label}>Expiry Date</Text>
          <TextInput 
            placeholder="MM/YY" 
            style={styles.input} 
            value={expiry} 
            onChangeText={setExpiry} 
          />
        </View>
        <View style={styles.inputHalf}>
          <Text style={styles.label}>CVV</Text>
          <TextInput 
            placeholder="123" 
            style={styles.input} 
            value={cvv} 
            onChangeText={setCvv} 
            keyboardType="numeric" 
            secureTextEntry={true} 
          />
        </View>
      </View>
      <TouchableOpacity style={styles.btnPay} onPress={onPay}>
        <Text style={styles.btnPayText}>Pay Now</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { 
    flexGrow: 1, 
    backgroundColor: '#fff', 
    padding: 20, 
    justifyContent: 'center' 
  },
  header: { 
    fontSize: 26, 
    fontWeight: 'bold', 
    marginBottom: 30, 
    textAlign: 'center', 
    color: '#333' 
  },
  inputGroup: { 
    marginBottom: 20 
  },
  label: { 
    fontSize: 16, 
    marginBottom: 5, 
    color: '#333' 
  },
  input: { 
    borderWidth: 1, 
    borderColor: '#ddd', 
    borderRadius: 8, 
    padding: 15, 
    fontSize: 18, 
    backgroundColor: '#F9F9F9' 
  },
  rowInput: { 
    flexDirection: 'row', 
    justifyContent: 'space-between' 
  },
  inputHalf: { 
    width: '48%', 
    marginBottom: 20 
  },
  btnPay: { 
    backgroundColor: '#4CAF50', 
    paddingVertical: 15, 
    borderRadius: 8, 
    alignItems: 'center', 
    marginTop: 20 
  },
  btnPayText: { 
    fontSize: 20, 
    color: '#FFF', 
    fontWeight: 'bold' 
  },
});

export default PaymentScreen;
