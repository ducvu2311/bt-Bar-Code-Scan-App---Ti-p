import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

const CartScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Your Cart 🛒</Text>
      <ScrollView style={styles.cartList}>
        {/* Ví dụ 2 sản phẩm. Bạn có thể render danh sách sản phẩm động nếu cần */}
        <View style={styles.cartItem}>
          <Text style={styles.itemText}>Product 1</Text>
          <Text style={styles.itemPrice}>$10.00</Text>
        </View>
        <View style={styles.cartItem}>
          <Text style={styles.itemText}>Product 2</Text>
          <Text style={styles.itemPrice}>$20.00</Text>
        </View>
      </ScrollView>
      <TouchableOpacity style={styles.btnCheckout} onPress={() => navigation.navigate('Payment')}>
        <Text style={styles.btnCheckoutText}>Proceed to Payment</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    padding: 20 
  },
  header: { 
    fontSize: 26, 
    fontWeight: 'bold', 
    marginBottom: 20, 
    color: '#333', 
    textAlign: 'center' 
  },
  cartList: { 
    flex: 1 
  },
  cartItem: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    paddingVertical: 15, 
    borderBottomWidth: 1, 
    borderColor: '#eee' 
  },
  itemText: { 
    fontSize: 18, 
    color: '#333' 
  },
  itemPrice: { 
    fontSize: 18, 
    color: '#333' 
  },
  btnCheckout: { 
    backgroundColor: '#FF9800', 
    paddingVertical: 15, 
    borderRadius: 8, 
    alignItems: 'center', 
    marginVertical: 20 
  },
  btnCheckoutText: { 
    fontSize: 20, 
    color: '#FFF', 
    fontWeight: 'bold' 
  },
});

export default CartScreen;
