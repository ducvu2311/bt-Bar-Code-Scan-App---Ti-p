import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  FlatList 
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const HomeScreen = ({ navigation }) => {
  // Dữ liệu ví dụ cho mục Explore More với ảnh cục bộ từ thư mục assets
  const exploreData = [
    { id: '1', name: 'Coca', image: require('../assets/coca.jpg') },
    { id: '2', name: 'Sprite', image: require('../assets/sprite.jpg') },
    { id: '3', name: 'Fanta', image: require('../assets/fanta.jpg') },
    { id: '4', name: 'Nước cam', image: require('../assets/scan.jpg') },
  ];

  const renderExploreItem = ({ item }) => (
    <View style={styles.exploreItem}>
      <Image source={item.image} style={styles.exploreItemImage} />
      <Text style={styles.exploreItemName}>{item.name}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerContainer}>
        <View>
          <Text style={styles.helloText}>Hello 👋</Text>
          <Text style={styles.userName}>Christie Doe</Text>
        </View>
        <Image
          // Sử dụng ảnh cục bộ cho avatar (đặt file avatar.png trong assets)
          source={require('../assets/avatar.jpg')}
          style={styles.avatar}
        />
      </View>

      {/* Insights */}
      <View style={styles.insightsContainer}>
        <View style={styles.insightBox}>
          <Text style={styles.insightTitle}>Scan new</Text>
          <Text style={styles.insightSubtitle}>Scanned 483</Text>
        </View>
        <View style={styles.insightBox}>
          <Text style={styles.insightTitle}>Counterfeits</Text>
          <Text style={styles.insightSubtitle}>32</Text>
        </View>
        <View style={styles.insightBox}>
          <Text style={styles.insightTitle}>Success</Text>
          <Text style={styles.insightSubtitle}>Checkouts 8</Text>
        </View>
        <View style={styles.insightBox}>
          <Text style={styles.insightTitle}>Directory</Text>
          <Text style={styles.insightSubtitle}>History 26</Text>
        </View>
      </View>

      {/* Explore More */}
      <Text style={styles.exploreTitle}>Explore More</Text>
      <FlatList
        data={exploreData}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={renderExploreItem}
        style={{ marginTop: 10 }}
      />

      {/* Bottom Tab (Minh họa) */}
      <View style={styles.bottomTab}>
        <TouchableOpacity style={styles.tabItem}>
          <Icon name="home-outline" size={24} color="#333" />
          <Text style={styles.tabItemText}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.tabItem} onPress={() => navigation.navigate('Scan')}>
          <Icon name="barcode-outline" size={24} color="#333" />
          <Text style={styles.tabItemText}>Scan</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.tabItem}>
          <Icon name="cart-outline" size={24} color="#333" />
          <Text style={styles.tabItemText}>Cart</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.tabItem}>
          <Icon name="person-outline" size={24} color="#333" />
          <Text style={styles.tabItemText}>Profile</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  helloText: {
    fontSize: 18,
    color: '#666',
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 5,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  insightsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  insightBox: {
    width: '48%',
    backgroundColor: '#F5F7FA',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  insightTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  insightSubtitle: {
    fontSize: 12,
    color: '#888',
    marginTop: 5,
  },
  exploreTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginTop: 20,
  },
  exploreItem: {
    width: 100,
    alignItems: 'center',
    marginRight: 15,
  },
  exploreItemImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginBottom: 5,
  },
  exploreItemName: {
    fontSize: 14,
    color: '#333',
  },
  bottomTab: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 70,
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#eee',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  tabItem: {
    alignItems: 'center',
  },
  tabItemText: {
    fontSize: 12,
    color: '#333',
    marginTop: 2,
  },
});
