import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const SplashScreen = ({ navigation }) => {
  useEffect(() => {
    // Hiển thị splash 3 giây rồi chuyển sang Home
    setTimeout(() => {
      navigation.replace('Home');
    }, 3000);
  }, []);

  return (
    <View style={styles.container}>
      <Image source={require('../assets/splash.jpg')} style={styles.image} />
      <Text style={styles.title}>Scan, Pay & Enjoy!</Text>
      <Text style={styles.subtitle}>Scan products easily and pay using your phone</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  image: { 
    width: 200, 
    height: 200, 
    resizeMode: 'contain', 
    marginBottom: 20 
  },
  title: { 
    fontSize: 26, 
    fontWeight: 'bold', 
    color: '#333' 
  },
  subtitle: { 
    fontSize: 16, 
    color: '#666', 
    marginTop: 10, 
    textAlign: 'center', 
    paddingHorizontal: 20 
  },
});

export default SplashScreen;
