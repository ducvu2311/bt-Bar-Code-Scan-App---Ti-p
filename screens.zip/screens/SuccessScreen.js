import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

const SuccessScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Image 
        source={{ uri: 'https://cdn-icons-png.flaticon.com/512/390/390973.png' }} 
        style={styles.icon} 
      />
      <Text style={styles.header}>Payment Successful!</Text>
      <Text style={styles.message}>
        Your order has been placed successfully. We will send your invoice shortly.
      </Text>
      <TouchableOpacity style={styles.btnHome} onPress={() => navigation.replace('Home')}>
        <Text style={styles.btnHomeText}>Back to Home</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    padding: 20, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  icon: { 
    width: 120, 
    height: 120, 
    marginBottom: 20 
  },
  header: { 
    fontSize: 28, 
    fontWeight: 'bold', 
    color: '#4CAF50', 
    textAlign: 'center', 
    marginBottom: 10 
  },
  message: { 
    fontSize: 16, 
    color: '#666', 
    textAlign: 'center', 
    marginBottom: 30, 
    paddingHorizontal: 20 
  },
  btnHome: { 
    backgroundColor: '#2196F3', 
    paddingVertical: 15, 
    paddingHorizontal: 30, 
    borderRadius: 8 
  },
  btnHomeText: { 
    fontSize: 20, 
    color: '#FFF', 
    fontWeight: 'bold' 
  },
});

export default SuccessScreen;
