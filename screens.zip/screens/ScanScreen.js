import React, { useEffect } from 'react';
import { 
  View, 
  Text, 
  Image, 
  StyleSheet, 
  TouchableOpacity 
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const ScanScreen = ({ navigation }) => {
  // Giả lập quá trình scan: sau 2 giây tự động chuyển sang Cart (có thể tuỳ chỉnh)
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('Cart');
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      {/* Khu vực hiển thị sản phẩm */}
      <View style={styles.scanArea}>
        <Image 
          source={require('../assets/scan.jpg')} 
          style={styles.productImage}
        />
        {/* Khung quét */}
        <View style={styles.scanFrameTop} />
        <View style={styles.scanFrameBottom} />
      </View>

      {/* Thông tin sản phẩm ở dưới cùng */}
      <View style={styles.productInfoContainer}>
        <View style={styles.productNameContainer}>
          <Text style={styles.brandName}>Lauren's</Text>
          <Text style={styles.productName}>Orange Juice</Text>
        </View>
        <TouchableOpacity style={styles.addButton}>
          <Icon name="add-outline" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ScanScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F6EFE8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanArea: {
    width: '100%',
    alignItems: 'center',
    position: 'relative',
    flex: 1,
    justifyContent: 'center',
  },
  productImage: {
    width: 200,
    height: 400,
    resizeMode: 'contain',
  },
  scanFrameTop: {
    position: 'absolute',
    top: '35%',
    width: 250,
    height: 250,
    borderWidth: 2,
    borderColor: '#999',
    borderStyle: 'solid',
    borderRadius: 20,
    opacity: 0.4,
  },
  scanFrameBottom: {
    position: 'absolute',
    top: '35%',
    width: 250,
    height: 250,
    borderWidth: 2,
    borderColor: '#999',
    borderStyle: 'solid',
    borderRadius: 20,
    opacity: 0.2,
  },
  productInfoContainer: {
    width: '100%',
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    paddingVertical: 15,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  productNameContainer: {
    flex: 1,
  },
  brandName: {
    fontSize: 16,
    color: '#777',
  },
  productName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 2,
  },
  addButton: {
    width: 44,
    height: 44,
    backgroundColor: '#FF9800',
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
